package com.movieapp.gateway.filter;

import com.movieapp.gateway.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
public class JwtAuthFilter implements GlobalFilter, Ordered {

    @Autowired
    private JwtUtil jwtUtil;

    // Public paths that do NOT require JWT
    private static final List<String> PUBLIC_PATHS = List.of(
            "/auth/login",
            "/auth/register",
            "/auth/refresh"
    );

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        String path = request.getURI().getPath();
        String method = request.getMethod().name();

        // ── 1. Log every incoming request ──────────────────────────────────────
        System.out.println("📥 Incoming Request: [" + method + "] " + path);

        // ── 2. Allow public routes without token ────────────────────────────────
        boolean isPublic = PUBLIC_PATHS.stream().anyMatch(path::startsWith);
        if (isPublic) {
            System.out.println("🔓 Public route – skipping JWT check");
            return chain.filter(exchange);
        }

        // ── 3. Extract Authorization header ─────────────────────────────────────
        String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            System.out.println("🚫 Missing or malformed Authorization header");
            return buildErrorResponse(exchange, HttpStatus.UNAUTHORIZED,
                    "Missing or invalid Authorization header");
        }

        String token = authHeader.substring(7); // strip "Bearer "

        // ── 4. Validate JWT ──────────────────────────────────────────────────────
        if (!jwtUtil.validateToken(token)) {
            System.out.println("🚫 Invalid or expired JWT token");
            return buildErrorResponse(exchange, HttpStatus.UNAUTHORIZED,
                    "Invalid or expired JWT token");
        }

        // ── 5. Extract user info and forward as headers to downstream services ──
        String username = jwtUtil.extractUsername(token);
        String role     = jwtUtil.extractRole(token);

        System.out.println("✅ Authenticated user: " + username + " | role: " + role);

        ServerHttpRequest mutatedRequest = request.mutate()
                .header("X-Authenticated-User", username)
                .header("X-User-Role", role != null ? role : "")
                .build();

        return chain.filter(exchange.mutate().request(mutatedRequest).build());
    }

    // ── Helper: build JSON error response ────────────────────────────────────────
    private Mono<Void> buildErrorResponse(ServerWebExchange exchange,
                                          HttpStatus status, String message) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(status);
        response.getHeaders().add(HttpHeaders.CONTENT_TYPE, "application/json");

        String body = String.format(
                "{\"status\": %d, \"error\": \"%s\", \"message\": \"%s\"}",
                status.value(), status.getReasonPhrase(), message
        );

        DataBuffer buffer = response.bufferFactory().wrap(body.getBytes());
        return response.writeWith(Mono.just(buffer));
    }

    @Override
    public int getOrder() {
        return -1; // Run before all other filters
    }
}
