package com.movieapp.auth.service;

import com.movieapp.auth.model.AuthDto;
import com.movieapp.auth.model.User;
import com.movieapp.auth.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AuthService {

    @Autowired
    private JwtUtil jwtUtil;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // In-memory user store (replace with DB in production)
    private final Map<String, User> userStore = new HashMap<>();

    public AuthService() {
        // Pre-load demo users
        userStore.put("admin", new User("admin",
                new BCryptPasswordEncoder().encode("admin123"), "ROLE_ADMIN"));
        userStore.put("user1", new User("user1",
                new BCryptPasswordEncoder().encode("user123"), "ROLE_USER"));
    }

    /**
     * Register a new user.
     */
    public AuthDto.AuthResponse register(AuthDto.RegisterRequest request) {
        if (userStore.containsKey(request.getUsername())) {
            throw new RuntimeException("Username already exists: " + request.getUsername());
        }

        String role = (request.getRole() != null) ? request.getRole() : "ROLE_USER";
        User newUser = new User(
                request.getUsername(),
                passwordEncoder.encode(request.getPassword()),
                role
        );
        userStore.put(request.getUsername(), newUser);

        String token = jwtUtil.generateToken(newUser.getUsername(), newUser.getRole());
        return new AuthDto.AuthResponse(token, newUser.getUsername(), newUser.getRole(),
                "User registered successfully");
    }

    /**
     * Login and return JWT token.
     */
    public AuthDto.AuthResponse login(AuthDto.LoginRequest request) {
        User user = userStore.get(request.getUsername());

        if (user == null || !passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid username or password");
        }

        String token = jwtUtil.generateToken(user.getUsername(), user.getRole());
        return new AuthDto.AuthResponse(token, user.getUsername(), user.getRole(),
                "Login successful");
    }
}
