package com.movieapp.booking.controller;

import com.movieapp.booking.model.Booking;
import com.movieapp.booking.model.BookingRequest;
import com.movieapp.booking.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/booking")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // Create a new booking
    @PostMapping("/create")
    public ResponseEntity<?> createBooking(
            @RequestBody BookingRequest request,
            @RequestHeader(value = "X-Authenticated-User", required = false) String username) {
        try {
            if (username == null) username = "anonymous";
            Booking booking = bookingService.createBooking(request, username);
            return ResponseEntity.ok(booking);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // Get all bookings
    @GetMapping("/all")
    public ResponseEntity<List<Booking>> getAllBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    // Get booking by ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookingById(@PathVariable Long id) {
        return bookingService.getBookingById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Get bookings for authenticated user
    @GetMapping("/my-bookings")
    public ResponseEntity<List<Booking>> getMyBookings(
            @RequestHeader(value = "X-Authenticated-User", required = false) String username) {
        if (username == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(bookingService.getBookingsByUser(username));
    }

    // Cancel a booking
    @PutMapping("/{id}/cancel")
    public ResponseEntity<?> cancelBooking(@PathVariable Long id) {
        return bookingService.cancelBooking(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/health")
    public ResponseEntity<?> health() {
        return ResponseEntity.ok(Map.of("status", "Booking Service is UP", "port", 8083));
    }
}
