package com.movieapp.booking.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Booking {
    private Long id;
    private Long movieId;
    private String movieTitle;
    private String username;
    private int seats;
    private String status;   // CONFIRMED, CANCELLED
    private LocalDateTime bookingTime;
}
