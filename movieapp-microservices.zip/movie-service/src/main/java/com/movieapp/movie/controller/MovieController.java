package com.movieapp.movie.controller;

import com.movieapp.movie.model.Movie;
import com.movieapp.movie.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/movies")
public class MovieController {

    @Autowired
    private MovieService movieService;

    // GET all movies
    @GetMapping("/all")
    public ResponseEntity<List<Movie>> getAllMovies(
            @RequestHeader(value = "X-Authenticated-User", required = false) String user) {
        System.out.println("📽️ Request by user: " + user);
        return ResponseEntity.ok(movieService.getAllMovies());
    }

    // GET movie by ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getMovieById(@PathVariable Long id) {
        return movieService.getMovieById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST add new movie (admin only)
    @PostMapping("/add")
    public ResponseEntity<Movie> addMovie(@RequestBody Movie movie) {
        return ResponseEntity.ok(movieService.addMovie(movie));
    }

    // PUT update movie
    @PutMapping("/{id}")
    public ResponseEntity<?> updateMovie(@PathVariable Long id, @RequestBody Movie movie) {
        return movieService.updateMovie(id, movie)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE movie
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMovie(@PathVariable Long id) {
        boolean deleted = movieService.deleteMovie(id);
        if (deleted) return ResponseEntity.ok(Map.of("message", "Movie deleted"));
        return ResponseEntity.notFound().build();
    }

    // Internal endpoint called by Booking Service
    @PutMapping("/{id}/reduce-seats")
    public ResponseEntity<?> reduceSeats(@PathVariable Long id,
                                          @RequestParam int count) {
        boolean success = movieService.reduceSeats(id, count);
        if (success) return ResponseEntity.ok(Map.of("message", "Seats reduced successfully"));
        return ResponseEntity.badRequest().body(Map.of("error", "Not enough seats or movie not found"));
    }

    @GetMapping("/health")
    public ResponseEntity<?> health() {
        return ResponseEntity.ok(Map.of("status", "Movie Service is UP", "port", 8082));
    }
}
