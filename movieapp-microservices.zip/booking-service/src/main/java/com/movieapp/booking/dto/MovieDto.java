package com.movieapp.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MovieDto {
    private Long id;
    private String title;
    private String genre;
    private String director;
    private int releaseYear;
    private double rating;
    private int availableSeats;
}
