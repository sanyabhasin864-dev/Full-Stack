package com.movieapp.booking.service;

import com.movieapp.booking.dto.MovieDto;
import com.movieapp.booking.model.Booking;
import com.movieapp.booking.model.BookingRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class BookingService {

    private final WebClient webClient;

    // In-memory booking store
    private final Map<Long, Booking> bookingStore = new HashMap<>();
    private long idCounter = 1;

    public BookingService(@Value("${services.movie-service.url}") String movieServiceUrl) {
        this.webClient = WebClient.builder()
                .baseUrl(movieServiceUrl)
                .build();
    }

    /**
     * Create a booking — calls Movie Service to verify movie and reduce seats.
     * Demonstrates synchronous inter-service communication via WebClient.
     */
    public Booking createBooking(BookingRequest request, String username) {

        // ── Step 1: Fetch movie from Movie Service ────────────────────────────
        MovieDto movie;
        try {
            movie = webClient.get()
                    .uri("/movies/{id}", request.getMovieId())
                    .retrieve()
                    .bodyToMono(MovieDto.class)
                    .block();  // block() for synchronous call
        } catch (WebClientResponseException e) {
            throw new RuntimeException("Movie not found with ID: " + request.getMovieId());
        }

        if (movie == null) {
            throw new RuntimeException("Movie not found with ID: " + request.getMovieId());
        }

        // ── Step 2: Check seat availability ──────────────────────────────────
        if (movie.getAvailableSeats() < request.getSeats()) {
            throw new RuntimeException("Not enough seats. Available: " + movie.getAvailableSeats());
        }

        // ── Step 3: Reduce seats in Movie Service ─────────────────────────────
        try {
            webClient.put()
                    .uri("/movies/{id}/reduce-seats?count={count}",
                            request.getMovieId(), request.getSeats())
                    .retrieve()
                    .bodyToMono(Void.class)
                    .block();
        } catch (WebClientResponseException e) {
            throw new RuntimeException("Failed to reserve seats: " + e.getMessage());
        }

        // ── Step 4: Save booking locally ──────────────────────────────────────
        Booking booking = new Booking(
                idCounter++,
                movie.getId(),
                movie.getTitle(),
                username,
                request.getSeats(),
                "CONFIRMED",
                LocalDateTime.now()
        );
        bookingStore.put(booking.getId(), booking);

        System.out.println("✅ Booking confirmed: " + booking.getId() + " for " + username);
        return booking;
    }

    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookingStore.values());
    }

    public Optional<Booking> getBookingById(Long id) {
        return Optional.ofNullable(bookingStore.get(id));
    }

    public List<Booking> getBookingsByUser(String username) {
        return bookingStore.values().stream()
                .filter(b -> b.getUsername().equals(username))
                .toList();
    }

    public Optional<Booking> cancelBooking(Long id) {
        Booking booking = bookingStore.get(id);
        if (booking == null) return Optional.empty();
        booking.setStatus("CANCELLED");
        return Optional.of(booking);
    }
}
