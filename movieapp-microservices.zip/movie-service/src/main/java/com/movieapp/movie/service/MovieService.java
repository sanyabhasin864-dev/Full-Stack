package com.movieapp.movie.service;

import com.movieapp.movie.model.Movie;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class MovieService {

    // In-memory movie store
    private final Map<Long, Movie> movieStore = new HashMap<>();

    public MovieService() {
        movieStore.put(1L, new Movie(1L, "Inception", "Sci-Fi", "Christopher Nolan", 2010, 8.8, 50));
        movieStore.put(2L, new Movie(2L, "The Dark Knight", "Action", "Christopher Nolan", 2008, 9.0, 30));
        movieStore.put(3L, new Movie(3L, "Interstellar", "Sci-Fi", "Christopher Nolan", 2014, 8.6, 40));
        movieStore.put(4L, new Movie(4L, "Avengers: Endgame", "Action", "Russo Brothers", 2019, 8.4, 100));
        movieStore.put(5L, new Movie(5L, "The Shawshank Redemption", "Drama", "Frank Darabont", 1994, 9.3, 20));
    }

    public List<Movie> getAllMovies() {
        return new ArrayList<>(movieStore.values());
    }

    public Optional<Movie> getMovieById(Long id) {
        return Optional.ofNullable(movieStore.get(id));
    }

    public Movie addMovie(Movie movie) {
        long newId = movieStore.size() + 1L;
        movie.setId(newId);
        movieStore.put(newId, movie);
        return movie;
    }

    public Optional<Movie> updateMovie(Long id, Movie updated) {
        if (!movieStore.containsKey(id)) return Optional.empty();
        updated.setId(id);
        movieStore.put(id, updated);
        return Optional.of(updated);
    }

    public boolean deleteMovie(Long id) {
        return movieStore.remove(id) != null;
    }

    public boolean reduceSeats(Long id, int count) {
        Movie movie = movieStore.get(id);
        if (movie == null || movie.getAvailableSeats() < count) return false;
        movie.setAvailableSeats(movie.getAvailableSeats() - count);
        return true;
    }
}
