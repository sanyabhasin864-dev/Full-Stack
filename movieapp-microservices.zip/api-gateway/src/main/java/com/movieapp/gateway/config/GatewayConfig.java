package com.movieapp.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Programmatic route definitions (alternative to application.yml routes).
 * These override/supplement the YAML config.
 */
@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()

                // ── Auth Service ──────────────────────────────────────────────
                .route("auth-service", r -> r
                        .path("/auth/**")
                        .filters(f -> f
                                .addRequestHeader("X-Gateway-Source", "api-gateway")
                                .rewritePath("/auth/(?<segment>.*)", "/auth/${segment}")
                        )
                        .uri("http://localhost:8081")
                )

                // ── Movie Service ─────────────────────────────────────────────
                .route("movie-service", r -> r
                        .path("/movies/**")
                        .filters(f -> f
                                .addRequestHeader("X-Gateway-Source", "api-gateway")
                                .rewritePath("/movies/(?<segment>.*)", "/movies/${segment}")
                        )
                        .uri("http://localhost:8082")
                )

                // ── Booking Service ───────────────────────────────────────────
                .route("booking-service", r -> r
                        .path("/booking/**")
                        .filters(f -> f
                                .addRequestHeader("X-Gateway-Source", "api-gateway")
                                .rewritePath("/booking/(?<segment>.*)", "/booking/${segment}")
                        )
                        .uri("http://localhost:8083")
                )

                .build();
    }
}
