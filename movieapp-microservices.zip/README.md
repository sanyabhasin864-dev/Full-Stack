# 🎬 Movie App — Microservices with API Gateway

A full microservices project with JWT authentication, API Gateway routing, and inter-service communication.

---

## 📐 Architecture

```
Client (Postman / Browser)
        │
        ▼
┌─────────────────────┐
│   API Gateway :8080  │  ← JWT validation, routing, logging
└──────┬──────┬───────┘
       │      │      │
       ▼      ▼      ▼
  Auth   Movie   Booking
  :8081  :8082   :8083
                   │
                   └──► Movie Service (internal WebClient call)
```

---

## 🗂️ Project Structure

```
├── api-gateway/
│   ├── src/main/java/com/movieapp/gateway/
│   │   ├── config/GatewayConfig.java       ← Route definitions
│   │   ├── filter/JwtAuthFilter.java       ← Global JWT filter
│   │   ├── security/SecurityConfig.java    ← WebFlux security
│   │   └── util/JwtUtil.java               ← Token validation
│   └── src/main/resources/application.yml
│
├── auth-service/
│   ├── src/main/java/com/movieapp/auth/
│   │   ├── controller/AuthController.java
│   │   ├── service/AuthService.java
│   │   ├── model/User.java / AuthDto.java
│   │   └── util/JwtUtil.java
│   └── src/main/resources/application.yml
│
├── movie-service/
│   ├── src/main/java/com/movieapp/movie/
│   │   ├── controller/MovieController.java
│   │   ├── service/MovieService.java
│   │   └── model/Movie.java
│   └── src/main/resources/application.yml
│
└── booking-service/
    ├── src/main/java/com/movieapp/booking/
    │   ├── controller/BookingController.java
    │   ├── service/BookingService.java     ← Uses WebClient to call Movie Service
    │   ├── model/Booking.java
    │   └── dto/MovieDto.java
    └── src/main/resources/application.yml
```

---

## 🔀 Gateway Routes

| Route Pattern | Target Service | Auth Required |
|---------------|---------------|---------------|
| `/auth/**`    | Auth Service :8081 | ❌ Public |
| `/movies/**`  | Movie Service :8082 | ✅ JWT Required |
| `/booking/**` | Booking Service :8083 | ✅ JWT Required |

---

## 🚀 How to Run

### Prerequisites
- Java 17+
- Maven 3.8+

### Step 1 — Start Auth Service
```bash
cd auth-service
mvn spring-boot:run
# Starts on http://localhost:8081
```

### Step 2 — Start Movie Service
```bash
cd movie-service
mvn spring-boot:run
# Starts on http://localhost:8082
```

### Step 3 — Start Booking Service
```bash
cd booking-service
mvn spring-boot:run
# Starts on http://localhost:8083
```

### Step 4 — Start API Gateway
```bash
cd api-gateway
mvn spring-boot:run
# Starts on http://localhost:8080
```

> ⚠️ Always start Auth, Movie, and Booking services **before** the Gateway.

---

## 🧪 Testing with Postman

### 1. Login (get JWT token)
```
POST http://localhost:8080/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```
**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "username": "admin",
  "role": "ROLE_ADMIN"
}
```

---

### 2. Get All Movies (with token)
```
GET http://localhost:8080/movies/all
Authorization: Bearer <your_token_here>
```

---

### 3. Create a Booking
```
POST http://localhost:8080/booking/create
Authorization: Bearer <your_token_here>
Content-Type: application/json

{
  "movieId": 1,
  "seats": 2
}
```

---

### 4. Test Unauthorized Access (no token)
```
GET http://localhost:8080/movies/all
→ 401 Unauthorized
```

---

### 5. Register New User
```
POST http://localhost:8080/auth/register
Content-Type: application/json

{
  "username": "newuser",
  "password": "password123",
  "role": "ROLE_USER"
}
```

---

## 👤 Pre-loaded Demo Users

| Username | Password  | Role       |
|----------|-----------|------------|
| admin    | admin123  | ROLE_ADMIN |
| user1    | user123   | ROLE_USER  |

---

## ⚙️ Gateway Configuration Details

The Gateway:
1. **Receives** every request on port 8080
2. **Logs** the method and path
3. **Checks** if route is public (`/auth/**` → skip JWT)
4. **Extracts** `Authorization: Bearer <token>` header
5. **Validates** JWT signature and expiry
6. **Forwards** request to correct service with added headers:
   - `X-Authenticated-User: <username>`
   - `X-User-Role: <role>`
   - `X-Gateway-Source: api-gateway`

---

## 🔗 Inter-Service Communication

**Booking Service → Movie Service** (via WebClient):
- When creating a booking, Booking Service calls Movie Service directly (port 8082) to:
  1. Verify the movie exists
  2. Check available seats
  3. Reduce seat count after booking

This is **synchronous** communication using Spring WebClient.

---

## 🔐 JWT Secret

The same secret key is used in both Auth Service and API Gateway.
Configured in each service's `application.yml` under `jwt.secret`.
